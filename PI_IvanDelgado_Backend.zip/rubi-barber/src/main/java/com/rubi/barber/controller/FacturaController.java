package com.rubi.barber.controller;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Factura;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.FacturaRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/facturas")
@CrossOrigin(origins = "*")
public class FacturaController {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private EmailService emailService;

    // Obtener todas las facturas (solo admin)
    @GetMapping
    public List<Factura> getAll(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) Long peluqueriaId
    ) {
        // Delegaremos a un nuevo método en el repositorio para filtrar
        if (startDate != null && endDate != null && peluqueriaId != null) {
            return facturaRepository.findByFechaEmisionBetweenAndPeluqueriaId(startDate.atStartOfDay(), endDate.atTime(LocalTime.MAX), peluqueriaId);
        } else if (peluqueriaId != null) {
            // Si solo hay peluqueriaId, obtener facturas de esa peluqueria
            return facturaRepository.findByPeluqueriaId(peluqueriaId);
        } else {
            // Si no hay filtros, obtener todas las facturas
            return facturaRepository.findAll();
        }
    }

    // Obtener facturas del cliente autenticado
    @GetMapping("/mis-facturas")
    public ResponseEntity<?> getMisFacturas(@AuthenticationPrincipal User user) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByEmail(user.getUsername());
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Usuario no encontrado");
        }
        List<Factura> facturas = facturaRepository.findByCitaClienteId(usuarioOpt.get().getId());
        return ResponseEntity.ok(facturas);
    }

    // Obtener una factura por ID
    @GetMapping("/{id}")
    public ResponseEntity<Factura> getFacturaById(@PathVariable Long id) {
        Optional<Factura> facturaOptional = facturaRepository.findById(id);
        return facturaOptional.map(ResponseEntity::ok)
                              .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear factura asociada a una cita confirmada
    @PostMapping("/{citaId}")
    public ResponseEntity<?> createFactura(@PathVariable Long citaId, @RequestBody Factura facturaData) {
        Optional<Cita> citaOpt = citaRepository.findById(citaId);
        if (citaOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Cita no encontrada");
        }

        Cita cita = citaOpt.get();
        if (!cita.isConfirmada()) {
            return ResponseEntity.badRequest().body("No se puede facturar una cita no confirmada");
        }

        Factura factura = new Factura();
        factura.setCita(cita);
        factura.setFechaEmision(LocalDateTime.now());
        factura.setMetodoPago(facturaData.getMetodoPago());
        factura.setMontoTotal(facturaData.getMontoTotal());

        return ResponseEntity.ok(facturaRepository.save(factura));
    }

    // Nuevo endpoint para actualizar el método de pago de una factura
    @PutMapping("/{id}/metodo-pago")
    public ResponseEntity<?> updateMetodoPago(
            @PathVariable Long id,
            @RequestParam String metodoPago) {
        Optional<Factura> facturaOpt = facturaRepository.findById(id);
        if (facturaOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Factura no encontrada");
        }

        Factura factura = facturaOpt.get();
        factura.setMetodoPago(metodoPago);
        facturaRepository.save(factura);

        return ResponseEntity.ok().body("Método de pago actualizado correctamente.");
    }

    // Nuevo endpoint para descargar una factura como PDF
    @GetMapping("/download/{id}/pdf")
    public ResponseEntity<byte[]> downloadFacturaPdf(@PathVariable Long id) {
        Optional<Factura> facturaOptional = facturaRepository.findById(id);
        if (!facturaOptional.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Factura factura = facturaOptional.get();
        Cita cita = citaRepository.findById(factura.getCita().getId()).orElse(null);
        Usuario cliente = usuarioRepository.findById(factura.getCliente().getId()).orElse(null);
        Usuario peluquero = (cita != null && cita.getPeluquero() != null) ? usuarioRepository.findById(cita.getPeluquero().getId()).orElse(null) : null;

        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                contentStream.setLeading(14.5f);
                contentStream.newLineAtOffset(25, 750);

                contentStream.showText("FACTURA DE RUBI BARBER");
                contentStream.newLine();
                contentStream.showText("--------------------------------");
                contentStream.newLine();
                contentStream.showText("ID Factura: " + factura.getId());
                contentStream.newLine();
                contentStream.showText("Fecha: " + factura.getFechaEmision().toLocalDate());
                contentStream.newLine();
                contentStream.showText("Total: " + String.format("%.2f", factura.getMontoTotal()) + "€");
                contentStream.newLine();
                contentStream.showText("Método de Pago: " + factura.getMetodoPago());
                contentStream.newLine();

                if (cliente != null) {
                    contentStream.newLine();
                    contentStream.showText("--- Detalles del Cliente ---");
                    contentStream.newLine();
                    contentStream.showText("Nombre: " + cliente.getNombre());
                    contentStream.newLine();
                    contentStream.showText("Email: " + cliente.getEmail());
                    contentStream.newLine();
                }

                if (peluquero != null) {
                    contentStream.newLine();
                    contentStream.showText("--- Detalles del Peluquero ---");
                    contentStream.newLine();
                    contentStream.showText("Nombre: " + peluquero.getNombre());
                    contentStream.newLine();
                }

                if (cita != null) {
                    contentStream.newLine();
                    contentStream.showText("--- Detalles de la Cita ---");
                    contentStream.newLine();
                    contentStream.showText("Fecha de Cita: " + cita.getFechaHora().toLocalDate() + " a las " + cita.getFechaHora().toLocalTime() + "h");
                    if (cita.getServicio() != null) {
                        contentStream.newLine();
                        contentStream.showText("Servicio: " + cita.getServicio().getNombre());
                    }
                }

                contentStream.endText();
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            document.save(baos);
            byte[] pdfBytes = baos.toByteArray();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "factura_" + id + ".pdf");
            headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);

        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Nuevo endpoint para enviar una factura por email
    @PostMapping("/send-email/{id}")
    public ResponseEntity<?> sendFacturaEmail(@PathVariable Long id) {
        Optional<Factura> facturaOptional = facturaRepository.findById(id);
        if (!facturaOptional.isPresent()) {
            return new ResponseEntity<>("Factura no encontrada.", HttpStatus.NOT_FOUND);
        }

        Factura factura = facturaOptional.get();
        // Obtener el cliente de la factura asegurándose de que esté completamente cargado
        Usuario cliente = usuarioRepository.findById(factura.getCliente().getId())
                                          .orElse(null);

        if (cliente == null || cliente.getEmail() == null || cliente.getEmail().isEmpty()) {
            return new ResponseEntity<>("Correo del cliente no disponible o no válido.", HttpStatus.BAD_REQUEST);
        }

        // Reutilizar la lógica de generación de PDF
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                contentStream.setLeading(14.5f);
                contentStream.newLineAtOffset(25, 750);

                contentStream.showText("FACTURA DE RUBI BARBER");
                contentStream.newLine();
                contentStream.showText("--------------------------------");
                contentStream.newLine();
                contentStream.showText("ID Factura: " + factura.getId());
                contentStream.newLine();
                contentStream.showText("Fecha: " + factura.getFechaEmision().toLocalDate());
                contentStream.newLine();
                contentStream.showText("Total: " + String.format("%.2f", factura.getMontoTotal()) + "€");
                contentStream.newLine();
                contentStream.showText("Método de Pago: " + factura.getMetodoPago());
                contentStream.newLine();

                if (cliente != null) {
                    contentStream.newLine();
                    contentStream.showText("--- Detalles del Cliente ---");
                    contentStream.newLine();
                    contentStream.showText("Nombre: " + cliente.getNombre());
                    contentStream.newLine();
                    contentStream.showText("Email: " + cliente.getEmail());
                    contentStream.newLine();
                }

                // Nota: Los detalles del peluquero y la cita se pueden añadir si son relevantes para el PDF
                // Para simplificar, no los incluyo aquí, pero se pueden copiar de downloadFacturaPdf

                contentStream.endText();
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            document.save(baos);
            byte[] pdfBytes = baos.toByteArray();

            // Enviar el email con el PDF adjunto
            emailService.enviarFacturaPdf(cliente.getEmail(), cliente.getNombre(), factura.getId(), pdfBytes);

            return new ResponseEntity<>("Email de factura enviado con éxito.", HttpStatus.OK);

        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Error al generar o enviar el PDF de la factura.", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) { // Capturar cualquier otra excepción del EmailService
            e.printStackTrace();
            return new ResponseEntity<>("Error al enviar el email: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
