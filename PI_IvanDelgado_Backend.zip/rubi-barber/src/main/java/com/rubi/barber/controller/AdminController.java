package com.rubi.barber.controller;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Factura;
import com.rubi.barber.model.Peluquero;
import com.rubi.barber.model.Servicio;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.model.Valoracion;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.FacturaRepository;
import com.rubi.barber.repository.PeluqueroRepository;
import com.rubi.barber.repository.ServicioRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.repository.ValoracionRepository;
import com.rubi.barber.dto.DashboardSummaryDTO;
import com.rubi.barber.dto.ValoracionPublicaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.time.DayOfWeek;
import java.time.temporal.TemporalAdjusters;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PeluqueroRepository peluqueroRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private ValoracionRepository valoracionRepository;

    // --- Gestión de usuarios ---

    @GetMapping("/usuarios")
    public List<Usuario> getAllUsuarios() {
        return usuarioRepository.findAll();
    }

    @PostMapping("/usuario/{id}/activar")
    public ResponseEntity<?> activarUsuario(@PathVariable Long id) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findById(id);
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Usuario no encontrado");
        }
        Usuario usuario = usuarioOpt.get();
        usuario.setActivo(!usuario.isActivo());
        usuarioRepository.save(usuario);
        return ResponseEntity.ok("Estado del usuario actualizado correctamente");
    }

    // --- Gestión de peluqueros ---

    @GetMapping("/peluqueros")
    public List<Peluquero> getAllPeluqueros() {
        return peluqueroRepository.findAll();
    }

    @PostMapping("/peluquero")
    public Peluquero createPeluquero(@RequestBody Peluquero peluquero) {
        return peluqueroRepository.save(peluquero);
    }

    @PostMapping("/peluquero/{id}/activar")
    public ResponseEntity<?> activarPeluquero(@PathVariable Long id) {
        Optional<Peluquero> peluqueroOpt = peluqueroRepository.findById(id);
        if (peluqueroOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Peluquero no encontrado");
        }
        Peluquero peluquero = peluqueroOpt.get();
        peluquero.setActivo(!peluquero.isActivo());
        peluqueroRepository.save(peluquero);
        return ResponseEntity.ok("Estado del peluquero actualizado correctamente");
    }

    // --- Estadísticas y citas ---

    @GetMapping("/citas/fecha")
    public ResponseEntity<?> getCitasPorFecha(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);
        List<Cita> citas = citaRepository.findByFechaHoraBetween(inicio, fin);
        return ResponseEntity.ok(citas);
    }

    @GetMapping("/citas/peluquero/{peluqueroId}")
    public ResponseEntity<?> getCitasPorPeluquero(@PathVariable Long peluqueroId) {
        List<Cita> citas = citaRepository.findByPeluqueroId(peluqueroId);
        return ResponseEntity.ok(citas);
    }

    @GetMapping("/citas/por-rango-fechas")
    public ResponseEntity<?> getCitasPorRangoFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        LocalDateTime inicioDateTime = inicio.atStartOfDay();
        LocalDateTime finDateTime = fin.atTime(LocalTime.MAX);
        List<Cita> citas = citaRepository.findByFechaHoraBetween(inicioDateTime, finDateTime);
        return ResponseEntity.ok(citas);
    }

    // Endpoint para el resumen del dashboard
    @GetMapping(value = "/dashboard/summary/{peluqueriaId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DashboardSummaryDTO> getDashboardSummary(@PathVariable Long peluqueriaId) {
        // Citas Hoy
        LocalDate hoy = LocalDate.now();
        LocalDateTime inicioDia = hoy.atStartOfDay();
        LocalDateTime finDia = hoy.atTime(LocalTime.MAX);
        Long citasHoy = citaRepository.countCitasTodayByPeluqueriaId(peluqueriaId, inicioDia, finDia);

        // Ingresos Semanales (de lunes a domingo de la semana actual)
        LocalDate inicioSemana = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate finSemana = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
        LocalDateTime inicioSemanaDateTime = inicioSemana.atStartOfDay();
        LocalDateTime finSemanaDateTime = finSemana.atTime(LocalTime.MAX);
        Double ingresosSemanales = facturaRepository.sumMontoTotalByFechaEmisionBetweenAndPeluqueriaId(
            inicioSemanaDateTime, finSemanaDateTime, peluqueriaId
        );

        // Peluqueros Activos
        Long peluquerosActivos = peluqueroRepository.countByPeluqueriaIdAndActivoTrue(peluqueriaId);

        DashboardSummaryDTO summary = new DashboardSummaryDTO(
            citasHoy,
            ingresosSemanales,
            peluquerosActivos
        );

        return ResponseEntity.ok(summary);
    }

    // --- Facturación ---

    @GetMapping("/ingresos/total")
    public Double getIngresosTotales() {
        return facturaRepository.sumMontoTotal();
    }

    @GetMapping("/ingresos/por-fecha")
    public Double getIngresosPorFecha(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        return facturaRepository.sumMontoTotalByFechaEmisionBetween(inicio.atStartOfDay(), fin.atTime(LocalTime.MAX));
    }

    // --- Valoraciones ---

    @GetMapping("/valoraciones")
    public List<Valoracion> getAllValoraciones() {
        return valoracionRepository.findAll();
    }

    @GetMapping("/valoraciones/peluquero/{peluqueroId}")
    public List<Valoracion> getValoracionesPorPeluquero(@PathVariable Long peluqueroId) {
        return valoracionRepository.findByPeluqueroId(peluqueroId);
    }

    // Nuevo endpoint para filtrar valoraciones por peluquería y rango de fechas
    @GetMapping("/valoraciones/por-peluqueria-y-fechas/{peluqueriaId}")
    public ResponseEntity<List<ValoracionPublicaDTO>> getValoracionesByPeluqueriaAndFechas(
            @PathVariable Long peluqueriaId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(LocalTime.MAX);

        List<Valoracion> valoraciones = valoracionRepository.findByPeluqueriaIdAndFechaValoracionBetween(
                peluqueriaId, startDateTime, endDateTime);
        
        List<ValoracionPublicaDTO> valoracionesDTO = valoraciones.stream()
            .map(v -> new ValoracionPublicaDTO(
                v.getId(),
                v.getPuntuacion(),
                v.getComentario(),
                v.getCliente() != null ? v.getCliente().getNombre() : "Anónimo",
                v.getCliente() != null ? v.getCliente().getImagenPerfilUrl() : null,
                v.getPeluquero() != null ? v.getPeluquero().getNombre() : "Desconocido",
                v.getCita() != null && v.getCita().getServicio() != null ? v.getCita().getServicio().getNombre() : "Desconocido",
                v.getFechaValoracion(),
                v.getCliente() != null ? v.getCliente().getId() : null
            ))
            .collect(Collectors.toList());

        return ResponseEntity.ok(valoracionesDTO);
    }

    // Nuevo endpoint para eliminar una valoración (para uso del administrador)
    @DeleteMapping("/valoraciones/{id}")
    public ResponseEntity<?> deleteValoracion(@PathVariable Long id) {
        if (!valoracionRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        valoracionRepository.deleteById(id);
        return ResponseEntity.ok().body("Valoración eliminada correctamente.");
    }
}
