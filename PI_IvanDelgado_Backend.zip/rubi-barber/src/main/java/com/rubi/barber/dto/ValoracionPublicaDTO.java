package com.rubi.barber.dto;

import java.time.LocalDateTime;

public class ValoracionPublicaDTO {
    private Long id;
    private int puntuacion;
    private String comentario;
    private String nombreCliente;
    private String imagenCliente;
    private String nombrePeluquero;
    private String nombreServicio;
    private LocalDateTime fecha;
    private Long clienteId;

    public ValoracionPublicaDTO() {}

    public ValoracionPublicaDTO(Long id, int puntuacion, String comentario, String nombreCliente, String imagenCliente, String nombrePeluquero, String nombreServicio, LocalDateTime fecha, Long clienteId) {
        this.id = id;
        this.puntuacion = puntuacion;
        this.comentario = comentario;
        this.nombreCliente = nombreCliente;
        this.imagenCliente = imagenCliente;
        this.nombrePeluquero = nombrePeluquero;
        this.nombreServicio = nombreServicio;
        this.fecha = fecha;
        this.clienteId = clienteId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getImagenCliente() {
        return imagenCliente;
    }

    public void setImagenCliente(String imagenCliente) {
        this.imagenCliente = imagenCliente;
    }

    public String getNombrePeluquero() {
        return nombrePeluquero;
    }

    public void setNombrePeluquero(String nombrePeluquero) {
        this.nombrePeluquero = nombrePeluquero;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }
} 