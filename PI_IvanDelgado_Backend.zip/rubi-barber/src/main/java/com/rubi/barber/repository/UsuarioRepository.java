package com.rubi.barber.repository;

import com.rubi.barber.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import com.rubi.barber.model.Rol;
import java.util.List;
import java.util.Optional;
import com.rubi.barber.model.Peluqueria;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    List<Usuario> findByRol(Rol rol);
    Optional<Usuario> findByPeluqueriaAndRol(Peluqueria peluqueria, Rol rol);
}
