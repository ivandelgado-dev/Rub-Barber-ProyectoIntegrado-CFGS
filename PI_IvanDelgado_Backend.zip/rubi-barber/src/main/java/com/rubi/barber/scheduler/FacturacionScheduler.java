package com.rubi.barber.scheduler;

import com.rubi.barber.service.FacturacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class FacturacionScheduler {

    @Autowired
    private FacturacionService facturacionService;

    // Este método se ejecutará cada 5 minutos (300000 milisegundos)
    @Scheduled(fixedRate = 300000)
    public void generarFacturasAutomaticamente() {
        System.out.println("Ejecutando tarea programada para procesar citas finalizadas y generar facturas...");
        facturacionService.procesarCitasFinalizadas();
        System.out.println("Tarea programada de facturación finalizada.");
    }
} 