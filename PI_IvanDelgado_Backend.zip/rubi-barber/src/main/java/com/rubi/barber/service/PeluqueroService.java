package com.rubi.barber.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.rubi.barber.model.Peluquero;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Valoracion;
import com.rubi.barber.model.Factura;
import com.rubi.barber.repository.PeluqueroRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.repository.PasswordResetTokenRepository;
import com.rubi.barber.repository.HorarioRepository;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.ValoracionRepository;
import com.rubi.barber.repository.FacturaRepository;
import com.rubi.barber.dto.PeluqueroDTO;
import com.rubi.barber.dto.UsuarioDTO;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PeluqueroService {

    @Autowired
    private PeluqueroRepository peluqueroRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordResetTokenRepository tokenRepository;

    @Autowired
    private HorarioRepository horarioRepository;

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private ValoracionRepository valoracionRepository;

    @Autowired
    private FacturaRepository facturaRepository;

    @Transactional
    public void eliminarPeluqueroYUsuario(Long idPeluquero) {
        Peluquero peluquero = peluqueroRepository.findById(idPeluquero)
            .orElseThrow(() -> new RuntimeException("Peluquero no encontrado"));

        // 1. Eliminar valoraciones asociadas a las citas del peluquero
        List<Valoracion> valoracionesDelPeluquero = valoracionRepository.findByPeluqueroId(idPeluquero);
        if (!valoracionesDelPeluquero.isEmpty()) {
            valoracionRepository.deleteAll(valoracionesDelPeluquero);
        }

        // 2. Eliminar facturas asociadas a las citas del peluquero
        List<Cita> citasDelPeluquero = citaRepository.findByPeluqueroId(idPeluquero);
        if (!citasDelPeluquero.isEmpty()) {
            // Obtener IDs de las citas para buscar facturas
            List<Long> citaIds = citasDelPeluquero.stream()
                                .map(Cita::getId)
                                .collect(Collectors.toList());
            List<Factura> facturasAsociadas = facturaRepository.findByCitaIdIn(citaIds);
            if (!facturasAsociadas.isEmpty()) {
                facturaRepository.deleteAll(facturasAsociadas);
            }
            citaRepository.deleteAll(citasDelPeluquero);
        }

        // 3. Eliminar horarios asociados al peluquero
        horarioRepository.deleteByPeluqueroId(idPeluquero);

        // 4. Eliminar el peluquero y su usuario
        Usuario usuario = peluquero.getUsuario();
        tokenRepository.deleteByUsuarioId(usuario.getId()); // Eliminar tokens de reseteo de contraseña del usuario
        peluqueroRepository.delete(peluquero);
        usuarioRepository.delete(usuario);
    }

    private PeluqueroDTO convertToDTO(Peluquero peluquero) {
        PeluqueroDTO dto = new PeluqueroDTO();
        dto.setId(peluquero.getId());
        dto.setNombre(peluquero.getNombre());
        dto.setEspecialidad(peluquero.getEspecialidad());
        dto.setActivo(peluquero.isActivo());
        dto.setRol(peluquero.getUsuario() != null ? peluquero.getUsuario().getRol().name() : null);
        dto.setEmail(peluquero.getUsuario() != null ? peluquero.getUsuario().getEmail() : null);

        if (peluquero.getUsuario() != null) {
            UsuarioDTO usuarioDTO = new UsuarioDTO();
            usuarioDTO.setId(peluquero.getUsuario().getId());
            usuarioDTO.setEmail(peluquero.getUsuario().getEmail());
            usuarioDTO.setActivo(peluquero.getUsuario().isActivo());
            usuarioDTO.setRol(peluquero.getUsuario().getRol().name());
            dto.setUsuarioPeluquero(usuarioDTO);
        }
        
        return dto;
    }
} 