package com.rubi.barber.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import com.rubi.barber.model.Cita;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;
import org.springframework.mail.javamail.MimeMessageHelper;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.MessagingException;
import jakarta.activation.DataSource;
import jakarta.mail.util.ByteArrayDataSource;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender emailSender;

    public void enviarEmailRecuperacion(String to, String token) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("noreply@rubibarber.com");
            message.setTo(to);
            message.setSubject("Recuperación de Contraseña - Rubí Barber");
            
            String emailContent = String.format(
                "Estimado cliente de Rubí Barber,\n\n" +
                "Hemos recibido una solicitud para restablecer tu contraseña. " +
                "Para proceder con el cambio, por favor haz clic en el siguiente enlace:\n\n" +
                "http://localhost:5173/reset-password?token=%s\n\n" +
                "Este enlace es válido por 24 horas por motivos de seguridad.\n\n" +
                "Si no solicitaste este cambio, por favor ignora este mensaje y tu contraseña permanecerá sin cambios.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber", token);
            
            message.setText(emailContent);
            
            emailSender.send(message);
            logger.info("Email de recuperación enviado exitosamente a: {}", to);
        } catch (Exception e) {
            logger.error("Error al enviar email de recuperación a: " + to, e);
            throw new RuntimeException("Error al enviar el email de recuperación", e);
        }
    }

    public void enviarEmailCancelacionPeluquero(String peluqueroEmail, String clienteNombre, String servicioNombre, String fechaHoraCita) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("noreply@rubibarber.com");
            message.setTo(peluqueroEmail);
            message.setSubject("Cita Cancelada - Rubí Barber");

            String emailContent = String.format(
                "Estimado/a peluquero/a,\n\n" +
                "Un cliente ha cancelado una cita.\n\n" +
                "Detalles de la cita cancelada:\n" +
                "Cliente: %s\n" +
                "Servicio: %s\n" +
                "Fecha y Hora: %s\n\n" +
                "Por favor, revisa tu agenda.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber",
                clienteNombre, servicioNombre, fechaHoraCita);

            message.setText(emailContent);

            emailSender.send(message);
            logger.info("Email de cancelación de cita enviado exitosamente a peluquero: {}", peluqueroEmail);
        } catch (Exception e) {
            logger.error("Error al enviar email de cancelación a peluquero: " + peluqueroEmail, e);
            // Considera si quieres relanzar la excepción o solo loguear el error
        }
    }

    public void enviarEmailRecordatorioCita(String clienteEmail, String clienteNombre, String servicioNombre, String peluqueroNombre, String fechaHoraCita) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("noreply@rubibarber.com");
            message.setTo(clienteEmail);
            message.setSubject("¡Recordatorio de tu próxima cita! - Rubí Barber");

            String emailContent = String.format(
                "Estimado/a %s,\n\n" +
                "Este es un amable recordatorio de tu próxima cita en Rubí Barber:\n\n" +
                "Servicio: %s\n" +
                "Peluquero: %s\n" +
                "Fecha y Hora: %s\n\n" +
                "¡Te esperamos! Por favor, llega a tiempo para tu cita.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber",
                clienteNombre, servicioNombre, peluqueroNombre, fechaHoraCita);

            message.setText(emailContent);

            emailSender.send(message);
            logger.info("Email de recordatorio de cita enviado exitosamente a cliente: {}", clienteEmail);
        } catch (Exception e) {
            logger.error("Error al enviar email de recordatorio a cliente: " + clienteEmail, e);
            // Considera si quieres relanzar la excepción o solo loguear el error
        }
    }

    public void enviarEmailBajaCliente(
        String adminEmail,
        List<String> peluqueroEmails,
        String clienteNombre,
        String clienteEmail,
        List<Cita> citasCanceladas
    ) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

            // Enviar email al administrador
            SimpleMailMessage adminMessage = new SimpleMailMessage();
            adminMessage.setFrom("noreply@rubibarber.com");
            adminMessage.setTo(adminEmail);
            adminMessage.setSubject("URGENTE: Baja de Cliente y Cancelación de Citas - Rubí Barber");
            
            String adminContent = String.format(
                "Estimado/a Administrador/a,\n\n" +
                "El cliente %s (Correo: %s) se ha dado de baja en la aplicación Rubí Barber.\n\n" +
                "Todas sus citas futuras han sido automáticamente canceladas.\n\n" +
                "Por favor, verifica el sistema para cualquier acción adicional necesaria.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber",
                clienteNombre, clienteEmail
            );
            adminMessage.setText(adminContent);
            emailSender.send(adminMessage);
            logger.info("Email de baja de cliente enviado a administrador: {}", adminEmail);

            // Enviar emails a peluqueros afectados
            if (peluqueroEmails != null && !peluqueroEmails.isEmpty()) {
                // Agrupar citas por peluquero para enviar un email consolidado a cada uno
                citasCanceladas.stream()
                    .filter(cita -> cita.getPeluquero() != null && 
                                     cita.getPeluquero().getUsuario() != null && 
                                     cita.getPeluquero().getUsuario().getEmail() != null) // Asegurar que el peluquero y su email no son nulos
                    .collect(Collectors.groupingBy(cita -> cita.getPeluquero().getUsuario().getEmail()))
                    .forEach((email, citasDelPeluquero) -> {
                        try {
                            SimpleMailMessage peluqueroMessage = new SimpleMailMessage();
                            peluqueroMessage.setFrom("noreply@rubibarber.com");
                            peluqueroMessage.setTo(email);
                            peluqueroMessage.setSubject("NOTIFICACIÓN: Citas Canceladas por Baja de Cliente - Rubí Barber");

                            StringBuilder peluqueroContentBuilder = new StringBuilder();
                            peluqueroContentBuilder.append(String.format(
                                "Estimado/a peluquero/a,\n\n" +
                                "El cliente %s (Correo: %s) se ha dado de baja en la aplicación.\n" +
                                "Las siguientes citas que tenías programadas con él/ella han sido canceladas automáticamente:\n\n",
                                clienteNombre, clienteEmail
                            ));

                            for (Cita cita : citasDelPeluquero) {
                                // Comprobaciones de nulidad adicionales dentro del bucle de formateo de citas
                                String servicioNombre = (cita.getServicio() != null) ? cita.getServicio().getNombre() : "Servicio Desconocido";
                                String fechaHoraCita = (cita.getFechaHora() != null) ? cita.getFechaHora().format(formatter) : "Fecha/Hora Desconocida";

                                peluqueroContentBuilder.append(String.format(
                                    "- Servicio: %s, Fecha y Hora: %s\n",
                                    servicioNombre,
                                    fechaHoraCita
                                ));
                            }
                            peluqueroContentBuilder.append("\nPor favor, actualiza tu agenda.\n\nSaludos cordiales,\nEl equipo de Rubí Barber");

                            peluqueroMessage.setText(peluqueroContentBuilder.toString());
                            emailSender.send(peluqueroMessage);
                            logger.info("Email de baja de cliente con citas canceladas enviado a peluquero: {}", email);
                        } catch (Exception e) {
                            logger.error("Error al enviar email de baja de cliente a peluquero " + email, e);
                            // Re-lanzar la excepción para que sea manejada por el UsuarioService y el controlador
                            throw new RuntimeException("Error al enviar email de baja de cliente a peluquero", e);
                        }
                    });
            }
        } catch (Exception e) {
            logger.error("Error general al enviar emails de baja de cliente:", e);
            // Re-lanzar la excepción para que sea manejada por el UsuarioService y el controlador
            throw new RuntimeException("Error general al enviar emails de baja de cliente", e);
        }
    }

    public void enviarFacturaPdf(String to, String clienteNombre, Long facturaId, byte[] pdfBytes) {
        try {
            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true); // true indica multipart message

            helper.setFrom("noreply@rubibarber.com");
            helper.setTo(to);
            helper.setSubject("Tu Factura de Rubí Barber - ID: " + facturaId);

            String emailContent = String.format(
                "Estimado/a %s,\n\n" +
                "Adjuntamos su factura con ID %d de Rubí Barber.\n\n" +
                "Gracias por su preferencia.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber",
                clienteNombre, facturaId);
            
            helper.setText(emailContent);

            // Adjuntar el PDF
            DataSource dataSource = new ByteArrayDataSource(pdfBytes, "application/pdf");
            helper.addAttachment("factura_" + facturaId + ".pdf", dataSource);

            emailSender.send(message);
            logger.info("Factura PDF {} enviada exitosamente a: {}", facturaId, to);
        } catch (MessagingException e) {
            logger.error("Error al construir o enviar el email con la factura PDF a: " + to, e);
            throw new RuntimeException("Error al enviar la factura por email", e);
        } catch (Exception e) {
            logger.error("Error inesperado al enviar el email con la factura PDF a: " + to, e);
            throw new RuntimeException("Error inesperado al enviar la factura por email", e);
        }
    }
} 