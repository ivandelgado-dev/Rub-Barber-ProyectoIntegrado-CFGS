package com.rubi.barber.repository;

import com.rubi.barber.model.Valoracion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import java.util.List;
import java.time.LocalDateTime;

public interface ValoracionRepository extends JpaRepository<Valoracion, Long> {

    List<Valoracion> findByPeluqueroId(Long peluqueroId);

    boolean existsByCitaId(Long citaId);

    List<Valoracion> findByPeluqueroIdIn(List<Long> peluqueroIds);

    @Query("SELECT AVG(v.puntuacion) FROM Valoracion v WHERE v.peluquero.id IN :peluqueroIds")
    Double findAverageRatingByPeluqueroIdIn(List<Long> peluqueroIds);

    @Modifying
    @Transactional
    @Query("DELETE FROM Valoracion v WHERE v.cita.id = :citaId")
    void deleteByCitaId(@Param("citaId") Long citaId);

    @Modifying
    @Transactional
    @Query("DELETE FROM Valoracion v WHERE v.cita.id IN :citaIds")
    void deleteByCitaIdIn(@Param("citaIds") List<Long> citaIds);

    List<Valoracion> findByClienteId(Long clienteId);

    @Query("SELECT v FROM Valoracion v WHERE v.peluquero.peluqueria.id = :peluqueriaId AND v.fechaValoracion BETWEEN :startDate AND :endDate")
    List<Valoracion> findByPeluqueriaIdAndFechaValoracionBetween(
        @Param("peluqueriaId") Long peluqueriaId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );
}
