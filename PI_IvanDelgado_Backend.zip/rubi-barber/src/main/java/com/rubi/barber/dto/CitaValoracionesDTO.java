package com.rubi.barber.dto;

import java.util.List;

public class CitaValoracionesDTO {
    private Long citaId;
    private String nombrePeluqueria;
    private List<ValoracionPublicaDTO> valoracionesPublicas;

    // Otros datos relevantes de la cita si se desean exponer

    public CitaValoracionesDTO() {}

    public CitaValoracionesDTO(Long citaId, String nombrePeluqueria, List<ValoracionPublicaDTO> valoracionesPublicas) {
        this.citaId = citaId;
        this.nombrePeluqueria = nombrePeluqueria;
        this.valoracionesPublicas = valoracionesPublicas;
    }

    public Long getCitaId() {
        return citaId;
    }

    public void setCitaId(Long citaId) {
        this.citaId = citaId;
    }

    public String getNombrePeluqueria() {
        return nombrePeluqueria;
    }

    public void setNombrePeluqueria(String nombrePeluqueria) {
        this.nombrePeluqueria = nombrePeluqueria;
    }

    public List<ValoracionPublicaDTO> getValoracionesPublicas() {
        return valoracionesPublicas;
    }

    public void setValoracionesPublicas(List<ValoracionPublicaDTO> valoracionesPublicas) {
        this.valoracionesPublicas = valoracionesPublicas;
    }
} 