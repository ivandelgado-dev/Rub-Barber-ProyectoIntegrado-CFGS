package com.rubi.barber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class RubiBarberApplication {

	public static void main(String[] args) {
		SpringApplication.run(RubiBarberApplication.class, args);
	}

}
