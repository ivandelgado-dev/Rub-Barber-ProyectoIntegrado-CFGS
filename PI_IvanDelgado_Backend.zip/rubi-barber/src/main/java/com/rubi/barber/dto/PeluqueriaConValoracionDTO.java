package com.rubi.barber.dto;

import com.rubi.barber.model.Peluqueria;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PeluqueriaConValoracionDTO {
    private Long id;
    private String nombre;
    private String direccion;
    private Double latitud;
    private Double longitud;
    private boolean activo;
    private Double rating; // Promedio de valoraciones
    private Long visitedCount; // Cantidad de citas completadas para la peluquería

    public PeluqueriaConValoracionDTO(Peluqueria peluqueria, Double rating, Long visitedCount) {
        this.id = peluqueria.getId();
        this.nombre = peluqueria.getNombre();
        this.direccion = peluqueria.getDireccion();
        this.latitud = peluqueria.getLatitud();
        this.longitud = peluqueria.getLongitud();
        this.activo = peluqueria.isActivo();
        this.rating = rating;
        this.visitedCount = visitedCount;
    }
} 