package com.rubi.barber.service;

import com.rubi.barber.model.Cita;
import com.rubi.barber.repository.CitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class CitaReminderScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CitaReminderScheduler.class);

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private EmailService emailService;

    // Tarea programada para enviar recordatorios 24 horas antes de la cita
    // Se ejecuta cada hora (3600000 ms)
    @Scheduled(fixedRate = 3600000)
    public void enviarRecordatoriosCitas() {
        logger.info("Ejecutando tarea programada para enviar recordatorios de citas...");
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime twentyFourHoursLater = now.plusHours(24).plusMinutes(15); // Un rango de 15 minutos para asegurar
        LocalDateTime twentyFourHoursBefore = now.plusHours(24).minusMinutes(15); // Un rango de 15 minutos para asegurar

        // Buscar citas que ocurran aproximadamente en 24 horas y que el recordatorio no haya sido enviado
        List<Cita> citasProximas = citaRepository.findByFechaHoraBetweenAndRecordatorioEnviadoFalse(twentyFourHoursBefore, twentyFourHoursLater);

        for (Cita cita : citasProximas) {
            try {
                // Verificar que la cita no haya sido procesada ya para un recordatorio
                // (se necesitaría un campo en Cita para esto, por ahora se enviará cada vez que caiga en el rango)
                // Por simplicidad, asumo que se enviará un recordatorio cada vez que la tarea se ejecute y la cita esté en el rango.
                // En un escenario real, se añadiría un flag `recordatorioEnviado` a la entidad Cita.

                String clienteEmail = cita.getCliente().getEmail();
                String clienteNombre = cita.getCliente().getNombre();
                String servicioNombre = cita.getServicio().getNombre();
                String peluqueroNombre = cita.getPeluquero().getNombre();
                String fechaHoraCita = cita.getFechaHora().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

                emailService.enviarEmailRecordatorioCita(clienteEmail, clienteNombre, servicioNombre, peluqueroNombre, fechaHoraCita);

                // Marcar la cita como recordatorio enviado para evitar duplicados
                cita.setRecordatorioEnviado(true);
                citaRepository.save(cita);

                logger.info("Recordatorio enviado para cita ID {}: {} a {}", cita.getId(), servicioNombre, clienteEmail);
            } catch (Exception e) {
                logger.error("Error al enviar recordatorio para cita ID " + cita.getId(), e);
            }
        }
        logger.info("Tarea de recordatorios de citas finalizada.");
    }
} 