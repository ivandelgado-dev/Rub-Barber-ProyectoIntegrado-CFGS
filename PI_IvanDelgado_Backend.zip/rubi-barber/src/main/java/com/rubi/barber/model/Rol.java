package com.rubi.barber.model;

public enum Rol {
    CLIENTE,
    PELUQUERO,
    ADMIN,
    BACKEND_ADMIN
}
