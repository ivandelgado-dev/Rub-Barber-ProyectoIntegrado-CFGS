package com.rubi.barber.repository;

import com.rubi.barber.model.Factura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {

    List<Factura> findByCitaClienteId(Long clienteId);

    @Query("SELECT COALESCE(SUM(f.montoTotal), 0) FROM Factura f")
    Double sumMontoTotal();

    @Query("SELECT COALESCE(SUM(f.montoTotal), 0) FROM Factura f WHERE f.fechaEmision BETWEEN :inicio AND :fin")
    Double sumMontoTotalByFechaEmisionBetween(@Param("inicio") LocalDateTime inicio, @Param("fin") LocalDateTime fin);

    @Query("SELECT COALESCE(SUM(f.montoTotal), 0) FROM Factura f " +
           "JOIN f.cita c JOIN c.peluquero p " +
           "WHERE p.peluqueria.id = :peluqueriaId AND FUNCTION('TIMESTAMPADD', MINUTE, c.servicio.duracion, c.fechaHora) BETWEEN :inicio AND :fin")
    Double sumMontoTotalByFechaEmisionBetweenAndPeluqueriaId(
        @Param("inicio") LocalDateTime inicio,
        @Param("fin") LocalDateTime fin,
        @Param("peluqueriaId") Long peluqueriaId
    );

    @Query("SELECT f FROM Factura f WHERE f.fechaEmision BETWEEN :inicio AND :fin AND f.peluqueria.id = :peluqueriaId")
    List<Factura> findByFechaEmisionBetweenAndPeluqueriaId(
            @Param("inicio") LocalDateTime inicio,
            @Param("fin") LocalDateTime fin,
            @Param("peluqueriaId") Long peluqueriaId
    );

    List<Factura> findByPeluqueriaId(Long peluqueriaId);

    List<Factura> findByCitaIdIn(List<Long> citaIds);

    // Eliminar facturas por ID de cita
    @Modifying
    @Transactional
    void deleteByCitaId(Long citaId);
}
