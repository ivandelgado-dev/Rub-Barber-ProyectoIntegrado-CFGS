package com.rubi.barber.dto;

public class UsuarioDTO {
    private Long id;
    private String email;
    private Boolean activo;
    private String rol;

    // Constructor vacío necesario para deserialización JSON
    public UsuarioDTO() {
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
} 