package com.rubi.barber.security;

import com.rubi.barber.model.Usuario;
import com.rubi.barber.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import org.springframework.security.core.GrantedAuthority;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario user = usuarioRepository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));

        System.out.println(">> Usuario encontrado:");
        System.out.println("   Email: " + user.getEmail());
        System.out.println("   Password (hash): " + user.getPassword());
        System.out.println("   Rol: " + user.getRol());
        logger.debug("Usuario encontrado: {}, Rol: {}", user.getEmail(), user.getRol());

        return new CustomUserDetails(user);
    }

}
