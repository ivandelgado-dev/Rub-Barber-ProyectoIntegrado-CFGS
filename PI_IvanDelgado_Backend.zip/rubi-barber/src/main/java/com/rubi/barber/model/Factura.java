package com.rubi.barber.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaEmision;
    private String metodoPago; // Podría ser un Enum en el futuro (ej. "Tarjeta", "Efectivo")
    private double montoTotal;

    @OneToOne
    @JoinColumn(name = "cita_id")
    @JsonIgnoreProperties({"factura"}) // Evitar bucles infinitos en JSON
    private Cita cita;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "cliente_id")
    @JsonIgnoreProperties({"citas", "password", "rol", "activo"})
    private Usuario cliente;

    @ManyToOne
    @JoinColumn(name = "peluqueria_id")
    @JsonIgnoreProperties({"servicios", "peluqueros", "usuario"})
    private Peluqueria peluqueria;

    @ManyToOne
    @JoinColumn(name = "peluquero_id")
    @JsonIgnoreProperties({"citas", "horarios", "especialidad", "activo"})
    private Peluquero peluquero;

    @ManyToOne
    @JoinColumn(name = "servicio_id")
    @JsonIgnoreProperties({"activo", "descripcion"})
    private Servicio servicio;

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(LocalDateTime fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public Cita getCita() {
        return cita;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    public Peluqueria getPeluqueria() {
        return peluqueria;
    }

    public void setPeluqueria(Peluqueria peluqueria) {
        this.peluqueria = peluqueria;
    }

    public Peluquero getPeluquero() {
        return peluquero;
    }

    public void setPeluquero(Peluquero peluquero) {
        this.peluquero = peluquero;
    }

    public Servicio getServicio() {
        return servicio;
    }

    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }
}
