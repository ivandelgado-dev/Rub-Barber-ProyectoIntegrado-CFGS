package com.rubi.barber.dto;

import java.util.List;

public class PeluqueriaValoracionesDTO {
    private String nombrePeluqueria;
    private List<ValoracionPublicaDTO> valoraciones;

    public PeluqueriaValoracionesDTO() {}

    public PeluqueriaValoracionesDTO(String nombrePeluqueria, List<ValoracionPublicaDTO> valoraciones) {
        this.nombrePeluqueria = nombrePeluqueria;
        this.valoraciones = valoraciones;
    }

    public String getNombrePeluqueria() {
        return nombrePeluqueria;
    }

    public void setNombrePeluqueria(String nombrePeluqueria) {
        this.nombrePeluqueria = nombrePeluqueria;
    }

    public List<ValoracionPublicaDTO> getValoraciones() {
        return valoraciones;
    }

    public void setValoraciones(List<ValoracionPublicaDTO> valoraciones) {
        this.valoraciones = valoraciones;
    }
} 