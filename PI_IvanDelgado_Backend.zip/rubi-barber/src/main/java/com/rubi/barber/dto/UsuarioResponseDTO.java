package com.rubi.barber.dto;

import com.rubi.barber.model.Peluqueria;
import com.rubi.barber.model.Rol;
import com.rubi.barber.model.Usuario;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioResponseDTO {
    private Long id;
    private String nombre;
    private String email;
    private Rol rol;
    private boolean activo;
    private String imagenPerfilUrl;
    
    // Getters y Setters explícitos para 'id'
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getters y Setters explícitos para 'nombre'
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getters y Setters explícitos para 'email'
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getters y Setters explícitos para 'rol'
    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    // Getters y Setters explícitos para 'activo'
    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    // Getters y Setters explícitos para 'imagenPerfilUrl'
    public String getImagenPerfilUrl() {
        return imagenPerfilUrl;
    }

    public void setImagenPerfilUrl(String imagenPerfilUrl) {
        this.imagenPerfilUrl = imagenPerfilUrl;
    }

    @JsonIgnoreProperties({"usuario", "peluqueros", "servicios"})
    private Peluqueria peluqueria;

    // Getters y Setters explícitos para 'peluqueria'
    public Peluqueria getPeluqueria() {
        return peluqueria;
    }

    public void setPeluqueria(Peluqueria peluqueria) {
        this.peluqueria = peluqueria;
    }

    public static UsuarioResponseDTO fromUsuario(Usuario usuario) {
        UsuarioResponseDTO dto = new UsuarioResponseDTO();
        dto.setId(usuario.getId());
        dto.setNombre(usuario.getNombre());
        dto.setEmail(usuario.getEmail());
        dto.setRol(usuario.getRol());
        dto.setActivo(usuario.isActivo());
        dto.setImagenPerfilUrl(usuario.getImagenPerfilUrl());
        
        // Forzar la carga de la peluquería
        if (usuario.getPeluqueria() != null) {
            Peluqueria peluqueria = usuario.getPeluqueria();
            // Acceder a los campos para forzar la carga
            peluqueria.getNombre();
            peluqueria.getDireccion();
            dto.setPeluqueria(peluqueria);
        }
        
        return dto;
    }
} 