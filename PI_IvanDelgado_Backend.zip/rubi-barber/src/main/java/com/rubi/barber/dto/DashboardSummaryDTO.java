package com.rubi.barber.dto;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class DashboardSummaryDTO {
    private Long citasHoy;
    private Double ingresosSemanales;
    private Long peluquerosActivos;

    public DashboardSummaryDTO(Long citasHoy, Double ingresosSemanales, Long peluquerosActivos) {
        this.citasHoy = citasHoy;
        this.ingresosSemanales = ingresosSemanales;
        this.peluquerosActivos = peluquerosActivos;
    }

    // Getters y Setters manuales
    public Long getCitasHoy() {
        return citasHoy;
    }

    public void setCitasHoy(Long citasHoy) {
        this.citasHoy = citasHoy;
    }

    public Double getIngresosSemanales() {
        return ingresosSemanales;
    }

    public void setIngresosSemanales(Double ingresosSemanales) {
        this.ingresosSemanales = ingresosSemanales;
    }

    public Long getPeluquerosActivos() {
        return peluquerosActivos;
    }

    public void setPeluquerosActivos(Long peluquerosActivos) {
        this.peluquerosActivos = peluquerosActivos;
    }
} 