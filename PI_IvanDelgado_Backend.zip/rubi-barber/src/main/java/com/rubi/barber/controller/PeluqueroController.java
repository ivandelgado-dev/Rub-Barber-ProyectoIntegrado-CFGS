package com.rubi.barber.controller;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Peluquero;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.model.Rol;
import com.rubi.barber.dto.PeluqueroDTO;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.PeluqueroRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.service.PasswordResetService;
import com.rubi.barber.service.PeluqueroService;
import com.rubi.barber.security.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.datetime.DateFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.rubi.barber.service.EmailService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/api/peluquero")
@CrossOrigin(origins = "*")
public class PeluqueroController {

    private static final Logger logger = LoggerFactory.getLogger(PeluqueroController.class);

    @Autowired
    private PeluqueroRepository peluqueroRepository;

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordResetService passwordResetService;

    @Autowired
    private PeluqueroService peluqueroService;

    @Autowired
    private JavaMailSender emailSender;

    @Autowired
    private EmailService emailService;

    // Obtener peluqueros de mi peluquería (para administradores)
    @GetMapping("")
    public ResponseEntity<?> getPeluquerosDeMiPeluqueria(@AuthenticationPrincipal CustomUserDetails user) {
        try {
            // 1. Obtener el usuario administrador
            Usuario admin = usuarioRepository.findByEmail(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

            // 2. Verificar que el usuario es administrador
            if (admin.getRol() != Rol.ADMIN) {
                return ResponseEntity.status(403).body("Solo los administradores pueden acceder a este recurso");
            }

            // 3. Verificar que tiene una peluquería asociada
            if (admin.getPeluqueria() == null) {
                return ResponseEntity.status(400).body("El administrador no tiene una peluquería asociada");
            }

            // 4. Obtener los peluqueros de la peluquería y convertirlos a DTOs
            List<Peluquero> peluqueros = peluqueroRepository.findByPeluqueriaId(admin.getPeluqueria().getId());
            List<PeluqueroDTO> peluquerosDTO = peluqueros.stream()
                .map(PeluqueroDTO::new)
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(peluquerosDTO);
        } catch (RuntimeException e) {
            return ResponseEntity.status(500).body("Error al obtener los peluqueros: " + e.getMessage());
        }
    }

    // Endpoint para obtener todos los peluqueros (mantenido por compatibilidad)
    @GetMapping("/todos")
    public List<Peluquero> getAllPeluqueros() {
        return peluqueroRepository.findAll();
    }

    // Crear nuevo peluquero
    @PostMapping("/crear")
    public ResponseEntity<?> createPeluquero(@RequestBody Peluquero peluquero, @AuthenticationPrincipal CustomUserDetails adminUser) {
        try {
            // 1. Obtener el admin que está creando el peluquero
            Usuario admin = usuarioRepository.findByEmail(adminUser.getUsername())
                .orElseThrow(() -> new RuntimeException("Admin no encontrado"));

            // 2. Verificar que el admin tiene una peluquería asociada
            if (admin.getPeluqueria() == null) {
                return ResponseEntity.badRequest().body("El administrador no tiene una peluquería asociada");
            }

            // 3. Crear y guardar primero el usuario
            if (peluquero.getUsuario() == null) {
                return ResponseEntity.badRequest().body("Se requiere información del usuario");
            }

            Usuario nuevoUsuario = peluquero.getUsuario();
            nuevoUsuario.setRol(Rol.PELUQUERO);
            nuevoUsuario = usuarioRepository.save(nuevoUsuario);

            // 4. Crear el peluquero con el usuario ya persistido
            Peluquero nuevoPeluquero = new Peluquero();
            nuevoPeluquero.setUsuario(nuevoUsuario);
            nuevoPeluquero.setPeluqueria(admin.getPeluqueria());
            nuevoPeluquero.setEspecialidad(peluquero.getEspecialidad());
            nuevoPeluquero.setActivo(true);
            nuevoPeluquero.setNombre(nuevoUsuario.getNombre());

            // 5. Guardar el peluquero
            Peluquero peluqueroGuardado = peluqueroRepository.save(nuevoPeluquero);

            // 6. Enviar email de recuperación de contraseña
            passwordResetService.solicitarRecuperacion(nuevoUsuario.getEmail());

            // 7. Convertir a DTO antes de devolver la respuesta
            return ResponseEntity.ok(new PeluqueroDTO(peluqueroGuardado));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al crear el peluquero: " + e.getMessage());
        }
    }

    // Nuevo endpoint: Obtener perfil del peluquero autenticado
    @GetMapping("/perfil")
    public ResponseEntity<?> getPerfilPeluquero(@AuthenticationPrincipal CustomUserDetails user) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByEmail(user.getUsername());
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Usuario no encontrado");
        }

        Optional<Peluquero> peluqueroOpt = peluqueroRepository.findByUsuarioId(usuarioOpt.get().getId());
        if (peluqueroOpt.isEmpty()) {
            return ResponseEntity.status(404).body("Peluquero no asociado a este usuario");
        }

        return ResponseEntity.ok(peluqueroOpt.get());
    }

    // Ver citas asignadas a este peluquero
    @GetMapping("/mis-citas")
    public ResponseEntity<?> verMisCitas(@AuthenticationPrincipal CustomUserDetails user) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByEmail(user.getUsername());
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Usuario no encontrado");
        }

        Optional<Peluquero> peluqueroOpt = peluqueroRepository.findByUsuarioId(usuarioOpt.get().getId());
        if (peluqueroOpt.isEmpty()) {
             return ResponseEntity.status(404).body("Peluquero no asociado a este usuario");
        }

        List<Cita> citas = citaRepository.findByPeluqueroId(peluqueroOpt.get().getId());
        
        return ResponseEntity.ok(citas);
    }

    // Confirmar asistencia a una cita
    @PostMapping("/confirmar/{citaId}")
    public ResponseEntity<?> confirmarCita(@AuthenticationPrincipal CustomUserDetails user, @PathVariable Long citaId) {
        Optional<Cita> citaOpt = citaRepository.findById(citaId);
        if (citaOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Cita no encontrada");
        }

        Cita cita = citaOpt.get();
        if (!cita.getPeluquero().getUsuario().getEmail().equals(user.getUsername())) {
            return ResponseEntity.status(403).body("No tienes permiso para confirmar esta cita");
        }

        cita.setConfirmada(true);
        citaRepository.save(cita);

        return ResponseEntity.ok("Cita confirmada correctamente");
    }

    // Cancelar una cita (anteriormente 'rechazar')
    @DeleteMapping("/cancelar/{citaId}")
    public ResponseEntity<?> cancelarCitaPeluquero(@AuthenticationPrincipal CustomUserDetails user, @PathVariable Long citaId) {
        Optional<Cita> citaOpt = citaRepository.findById(citaId);
        if (citaOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Cita no encontrada");
        }

        Cita cita = citaOpt.get();
        if (!cita.getPeluquero().getUsuario().getEmail().equals(user.getUsername())) {
            return ResponseEntity.status(403).body("No tienes permiso para cancelar esta cita");
        }

        // Obtener los datos necesarios para el correo
        String clienteEmail = cita.getCliente().getEmail();
        String clienteNombre = cita.getCliente().getNombre();
        String servicioNombre = cita.getServicio().getNombre();
        String fechaHoraCita = cita.getFechaHora().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        // Enviar correo al cliente
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("noreply@rubibarber.com");
            message.setTo(clienteEmail);
            message.setSubject("Cita Cancelada - Rubí Barber");

            String emailContent = String.format(
                "Estimado/a %s,\n\n" +
                "Te informamos que tu cita ha sido cancelada por el peluquero.\n\n" +
                "Detalles de la cita cancelada:\n" +
                "Servicio: %s\n" +
                "Fecha y Hora: %s\n\n" +
                "Por favor, contacta con la peluquería si necesitas más información.\n\n" +
                "Saludos cordiales,\n" +
                "El equipo de Rubí Barber",
                clienteNombre, servicioNombre, fechaHoraCita);

            message.setText(emailContent);
            emailSender.send(message);
        } catch (Exception e) {
            logger.error("Error al enviar email de cancelación a cliente: " + clienteEmail, e);
            // Continuamos con la cancelación aunque falle el envío del correo
        }

        citaRepository.deleteById(citaId);
        return ResponseEntity.ok("Cita cancelada y eliminada correctamente");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> eliminarPeluquero(@PathVariable Long id, @AuthenticationPrincipal CustomUserDetails user) {
        // 1. Obtener el usuario administrador
        Usuario admin = usuarioRepository.findByEmail(user.getUsername())
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        // 2. Verificar que el administrador tiene una peluquería asociada
        if (admin.getPeluqueria() == null) {
            return ResponseEntity.status(400).body("El administrador no tiene una peluquería asociada.");
        }

        // 3. Obtener el peluquero a eliminar
        Peluquero peluquero = peluqueroRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Peluquero no encontrado"));

        // 4. Verificar si el peluquero pertenece a la peluquería del administrador
        if (!peluquero.getPeluqueria().getId().equals(admin.getPeluqueria().getId())) {
            return ResponseEntity.status(403).body("No tienes permiso para eliminar este peluquero porque no pertenece a tu peluquería.");
        }
        
        peluqueroService.eliminarPeluqueroYUsuario(id);
        return ResponseEntity.ok().build();
    }
}
