package com.rubi.barber.service;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Peluquero;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.model.Rol; // Importar Rol
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.repository.ValoracionRepository;
import com.rubi.barber.repository.PasswordResetTokenRepository;
import com.rubi.barber.repository.PeluqueroRepository; // Necesario para buscar peluqueros por ID de usuario si fuera el caso
import com.rubi.barber.repository.FacturaRepository; // Importar FacturaRepository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UsuarioService {

    private static final Logger logger = LoggerFactory.getLogger(UsuarioService.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private ValoracionRepository valoracionRepository;

    @Autowired
    private PasswordResetTokenRepository passwordResetTokenRepository;

    @Autowired
    private PeluqueroRepository peluqueroRepository; // Para manejar si el usuario es un peluquero

    @Autowired
    private EmailService emailService;

    @Autowired
    private FacturaRepository facturaRepository; // Inyectar FacturaRepository

    @Transactional
    public void eliminarUsuarioYNotificar(Long usuarioId) throws Exception {
        logger.info("Iniciando proceso de eliminación de usuario con ID: {}", usuarioId);

        Usuario usuarioAEliminar = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + usuarioId));

        // Obtener el rol del usuario para manejar diferentes lógicas de eliminación
        Rol rolUsuario = usuarioAEliminar.getRol();

        // Si el usuario es un PELUQUERO o ADMIN con peluquería asociada
        if (rolUsuario == Rol.PELUQUERO || (rolUsuario == Rol.ADMIN && usuarioAEliminar.getPeluqueria() != null)) {
            // Lógica para peluqueros o administradores asociados a peluquerías (puede ser más compleja,
            // pero por ahora nos centramos en el caso CLIENTE)
            // Si el usuario es un peluquero, se necesitaría una lógica similar a PeluqueroService.eliminarPeluqueroYUsuario
            // para limpiar sus citas, horarios, etc. Por ahora, nos centraremos en el rol CLIENTE.
            // Si es un ADMIN con peluquería, la lógica de eliminación es más delicada para no romper la estructura de la peluquería.
            logger.warn("Intento de eliminar un usuario con rol PELUQUERO o ADMIN con peluquería. Esta lógica no está completamente implementada aquí para estos roles.");
            throw new UnsupportedOperationException("La eliminación directa de usuarios con rol PELUQUERO o ADMIN (con peluquería asociada) no está permitida a través de este endpoint.");
        }


        // Lógica específica para rol CLIENTE:
        // 1. Obtener todas las citas futuras del cliente
        List<Cita> citasFuturasCliente = citaRepository.findByClienteId(usuarioId).stream()
                .filter(cita -> cita.getFechaHora().isAfter(LocalDateTime.now()))
                .collect(Collectors.toList());

        List<Peluquero> peluquerosAfectados = new ArrayList<>();
        List<Cita> citasCanceladas = new ArrayList<>();

        // Recopilar peluqueros afectados y marcar citas para cancelación
        for (Cita cita : citasFuturasCliente) {
            peluquerosAfectados.add(cita.getPeluquero());
            citasCanceladas.add(cita);
        }

        // Antes de eliminar las citas, eliminar las facturas asociadas a ellas
        List<Cita> todasLasCitasDelCliente = citaRepository.findByClienteId(usuarioId);
        for (Cita cita : todasLasCitasDelCliente) {
            facturaRepository.deleteByCitaId(cita.getId()); // Asumiendo que existe un método deleteByCitaId en FacturaRepository
        }
        
        // 2. Eliminar todas las valoraciones hechas por este cliente
        valoracionRepository.deleteAll(valoracionRepository.findByClienteId(usuarioId)); // Asumiendo findByClienteId existe

        // 3. Eliminar todas las citas del cliente (futuras y pasadas)
        citaRepository.deleteAll(citaRepository.findByClienteId(usuarioId));

        // 4. Eliminar cualquier token de restablecimiento de contraseña asociado al usuario
        passwordResetTokenRepository.deleteByUsuarioId(usuarioId);

        // 5. Eliminar el usuario
        usuarioRepository.delete(usuarioAEliminar);
        logger.info("Usuario con ID: {} eliminado exitosamente.", usuarioId);

        // 6. Enviar notificaciones
        // Recopilar emails de peluqueros únicos
        List<String> peluqueroEmails = peluquerosAfectados.stream()
                                                            .filter(p -> p != null && p.getUsuario() != null && p.getUsuario().getEmail() != null)
                                                            .map(peluquero -> peluquero.getUsuario().getEmail())
                                                            .distinct()
                                                            .collect(Collectors.toList());
        
        // Obtener el email del administrador de la peluquería del cliente, si tiene citas futuras.
        // Si no se encuentra, se usará un admin genérico o el email por defecto.
        String adminEmail = "admin@rubibarber.com"; // Email por defecto
        if (!citasFuturasCliente.isEmpty()) {
            // Asumimos que el cliente está predominantemente ligado a una peluquería a través de sus citas futuras.
            // Tomamos la primera peluquería de las citas futuras para encontrar a su administrador.
            Cita primeraCita = citasFuturasCliente.get(0);
            if (primeraCita.getPeluquero() != null && primeraCita.getPeluquero().getPeluqueria() != null) {
                Long peluqueriaId = primeraCita.getPeluquero().getPeluqueria().getId();
                
                Optional<Usuario> adminPeluqueriaOpt = usuarioRepository.findByPeluqueriaAndRol(primeraCita.getPeluquero().getPeluqueria(), Rol.ADMIN);
                if (adminPeluqueriaOpt.isEmpty()) {
                    adminPeluqueriaOpt = usuarioRepository.findByPeluqueriaAndRol(primeraCita.getPeluquero().getPeluqueria(), Rol.BACKEND_ADMIN);
                }

                if (adminPeluqueriaOpt.isPresent()) {
                    adminEmail = adminPeluqueriaOpt.get().getEmail();
                } else {
                    logger.warn("No se encontró un administrador para la peluquería con ID: {} del cliente. Se enviará al admin por defecto.", peluqueriaId);
                }
            } else {
                 logger.warn("La primera cita futura del cliente no tiene peluquero o peluquería asociada. Se enviará al admin por defecto.");
            }
        } else {
            // Si no hay citas futuras, se puede enviar a un administrador general si existe
            List<Usuario> adminGeneralList = usuarioRepository.findByRol(Rol.ADMIN);
            Optional<Usuario> adminGeneralOpt = adminGeneralList.stream().findFirst();

            if (adminGeneralOpt.isEmpty()){
                 List<Usuario> backendAdminList = usuarioRepository.findByRol(Rol.BACKEND_ADMIN);
                 adminGeneralOpt = backendAdminList.stream().findFirst();
            }
            if(adminGeneralOpt.isPresent()){
                adminEmail = adminGeneralOpt.get().getEmail();
            } else {
                logger.warn("No hay citas futuras y no se encontró un administrador general. Se enviará al admin por defecto.");
            }
        }

        // Llamar al servicio de email para enviar las notificaciones
        try {
            emailService.enviarEmailBajaCliente(
                adminEmail,
                peluqueroEmails,
                usuarioAEliminar.getNombre(),
                usuarioAEliminar.getEmail(),
                citasCanceladas
            );
            logger.info("Notificaciones de baja de usuario enviadas para ID: {}", usuarioId);
        } catch (Exception e) {
            logger.error("Error al enviar notificaciones de baja de usuario para ID: {}", usuarioId, e);
            throw new RuntimeException("Error al enviar notificaciones de baja de usuario", e);
        }
    }
} 