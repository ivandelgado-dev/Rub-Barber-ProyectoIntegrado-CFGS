package com.rubi.barber.service.impl;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Factura;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.FacturaRepository;
import com.rubi.barber.service.FacturacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class FacturacionServiceImpl implements FacturacionService {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private FacturaRepository facturaRepository;

    @Override
    public Factura generarFactura(Cita cita) {
        if (cita == null || cita.getServicio() == null || cita.getCliente() == null || cita.getServicio().getPeluqueria() == null) {
            throw new IllegalArgumentException("Cita o sus entidades relacionadas no pueden ser nulas para generar una factura.");
        }

        Factura factura = new Factura();
        factura.setCita(cita);
        factura.setFechaEmision(LocalDateTime.now());
        factura.setMontoTotal(cita.getServicio().getPrecio());
        factura.setMetodoPago("Desconocido"); // Esto podría ser configurable o venir de un input futuro
        factura.setCliente(cita.getCliente());
        factura.setPeluqueria(cita.getServicio().getPeluqueria());
        factura.setPeluquero(cita.getPeluquero());
        factura.setServicio(cita.getServicio());

        return facturaRepository.save(factura);
    }

    @Override
    public void procesarCitasFinalizadas() {
        // Buscar citas confirmadas y cuya hora de finalización ya haya pasado, y que no estén facturadas
        List<Cita> citasPendientesDeFacturar = citaRepository.findFinishedUnbilledAppointments(LocalDateTime.now());

        for (Cita cita : citasPendientesDeFacturar) {
            try {
                generarFactura(cita);
                // Ya no necesitamos establecer el estado de la cita a "FINALIZADA" aquí,
                // ya que la consulta findFinishedUnbilledAppointments se encarga de que no se facture dos veces.
                // cita.setEstado("FINALIZADA"); 
                // citaRepository.save(cita);
            } catch (Exception e) {
                System.err.println("Error al generar factura para la cita " + cita.getId() + ": " + e.getMessage());
                // Opcional: manejar el error de forma más robusta (ej. loggear, notificar)
            }
        }
    }

    @Override
    public List<Factura> obtenerTodasLasFacturas() {
        return facturaRepository.findAll();
    }
} 