package com.rubi.barber.controller;

import com.rubi.barber.model.Cita;
import com.rubi.barber.model.Peluquero;
import com.rubi.barber.model.Servicio;
import com.rubi.barber.model.Usuario;
import com.rubi.barber.model.Valoracion;
import com.rubi.barber.repository.CitaRepository;
import com.rubi.barber.repository.PeluqueroRepository;
import com.rubi.barber.repository.ServicioRepository;
import com.rubi.barber.repository.UsuarioRepository;
import com.rubi.barber.repository.ValoracionRepository;
import com.rubi.barber.security.JwtService;
import com.rubi.barber.security.CustomUserDetails;
import com.rubi.barber.service.EmailService;
import com.rubi.barber.dto.CitaValoracionesDTO;
import com.rubi.barber.dto.ValoracionPublicaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/citas")
@CrossOrigin(origins = "*")
public class CitaController {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private PeluqueroRepository peluqueroRepository;

    @Autowired
    private ValoracionRepository valoracionRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private EmailService emailService;

    // Obtener todas las citas
    @GetMapping
    public List<Cita> getAll() {
        return citaRepository.findAll();
    }

    // Obtener una cita por ID con seguridad para el cliente
    @GetMapping("/{id}")
    public ResponseEntity<?> getCitaById(@PathVariable Long id, Authentication authentication) {
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Long authenticatedUserId = userDetails.getId();

        Optional<Cita> citaOptional = citaRepository.findById(id);
        if (citaOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Cita cita = citaOptional.get();

        // Verificar que el usuario autenticado es el cliente de la cita
        if (!cita.getCliente().getId().equals(authenticatedUserId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para ver esta cita.");
        }

        // Obtener el nombre de la peluquería
        String nombrePeluqueria = cita.getPeluquero().getPeluqueria().getNombre();

        // Obtener las valoraciones públicas del peluquero
        List<Valoracion> valoraciones = valoracionRepository.findByPeluqueroId(cita.getPeluquero().getId());
        List<ValoracionPublicaDTO> valoracionesPublicas = valoraciones.stream()
            .map(valoracion -> new ValoracionPublicaDTO(
                valoracion.getId(),
                valoracion.getPuntuacion(),
                valoracion.getComentario(),
                valoracion.getCliente().getNombre(),
                valoracion.getCliente().getImagenPerfilUrl(),
                valoracion.getPeluquero().getUsuario().getNombre(),
                valoracion.getCita().getServicio().getNombre(),
                valoracion.getFechaValoracion(),
                valoracion.getCliente().getId()
            ))
            .collect(Collectors.toList());

        // Crear y devolver el DTO
        CitaValoracionesDTO dto = new CitaValoracionesDTO(
            cita.getId(),
            nombrePeluqueria,
            valoracionesPublicas
        );

        return ResponseEntity.ok(dto);
    }

    @PostMapping("/{servicioId}/{peluqueroId}")
    public ResponseEntity<?> create(
            Authentication authentication,
            @PathVariable Long servicioId,
            @PathVariable Long peluqueroId,
            @RequestBody Cita cita
    ) {
        // Obtenemos el principal autenticado, que ahora es CustomUserDetails
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Long usuarioId = userDetails.getId();

        Usuario usuario = usuarioRepository.findById(usuarioId).orElse(null);
        Servicio servicio = servicioRepository.findById(servicioId).orElse(null);
        Peluquero peluquero = peluqueroRepository.findById(peluqueroId).orElse(null);

        if (usuario == null || servicio == null || peluquero == null) {
            return ResponseEntity.badRequest().body("Usuario, servicio o peluquero no encontrado.");
        }

        LocalDateTime inicio = cita.getFechaHora();
        LocalDateTime fin = inicio.plusMinutes(servicio.getDuracion());

        // Verificar solapamiento con otras citas del peluquero
        boolean haySolapamientoPeluquero = citaRepository.existeSolapamiento(peluqueroId, inicio, fin);
        if (haySolapamientoPeluquero) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("El peluquero ya tiene una cita en ese horario.");
        }

        // Verificar solapamiento con otras citas del cliente
        boolean haySolapamientoCliente = citaRepository.existeSolapamientoCliente(usuarioId, inicio, fin);
        if (haySolapamientoCliente) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Ya tienes una cita programada en ese horario.");
        }

        cita.setCliente(usuario);      // Se asigna aquí, no viene del JSON
        cita.setServicio(servicio);    // Lo mismo
        cita.setPeluquero(peluquero);  // Y este también
        cita.setConfirmada(true); // Confirmar la cita automáticamente

        return ResponseEntity.ok(citaRepository.save(cita));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Long id,
            Authentication authentication
    ) {
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Long authenticatedUserId = userDetails.getId();

        Cita cita = citaRepository.findById(id).orElse(null);

        if (cita == null) {
            return ResponseEntity.notFound().build();
        }

        // Verificar que el usuario autenticado es el propietario de la cita
        if (!cita.getCliente().getId().equals(authenticatedUserId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para cancelar esta cita.");
        }

        // Preparar y enviar el correo electrónico al peluquero
        String peluqueroEmail = cita.getPeluquero().getUsuario().getEmail();
        String clienteNombre = cita.getCliente().getNombre();
        String servicioNombre = cita.getServicio().getNombre();

        // Formatear la fecha y hora de la cita para el correo
        String fechaHoraCita = cita.getFechaHora().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        citaRepository.delete(cita);

        emailService.enviarEmailCancelacionPeluquero(peluqueroEmail, clienteNombre, servicioNombre, fechaHoraCita);

        return ResponseEntity.ok().build();
    }
}
