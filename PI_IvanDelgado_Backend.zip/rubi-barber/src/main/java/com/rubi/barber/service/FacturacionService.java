package com.rubi.barber.service;

import com.rubi.barber.model.Factura;
import com.rubi.barber.model.Cita;
import java.util.List;

public interface FacturacionService {
    Factura generarFactura(Cita cita);
    void procesarCitasFinalizadas();
    List<Factura> obtenerTodasLasFacturas();
} 